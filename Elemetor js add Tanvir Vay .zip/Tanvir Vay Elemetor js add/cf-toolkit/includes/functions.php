<?php

function cf_get_post_types( $args = array(), $diff_key = array() ) {
    $default = [
        'public'            => true,
        'show_in_nav_menus' => true,
    ];
    $args       = array_merge( $default, $args );
    $post_types = get_post_types( $args, 'objects' );
    $post_types = wp_list_pluck( $post_types, 'label', 'name' );

    if ( !empty( $diff_key ) ) {
        $post_types = array_diff_key( $post_types, $diff_key );
    }

    return $post_types;
}
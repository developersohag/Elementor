<?php


use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Image_Size;

class CF_Content_Box_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return "cf_content_box";
    }
    public function get_title() {
        return "CF Content Box";
    }
    
    public function get_icon() {
        return "hm hm-blog-content";
    }
    public function get_categories() {
        return [ 'general', 'cf-cat' ];
    }

	public function get_style_depends() {
		return [ 'cf-style' ];
	}
	public function get_script_depends() {
		return [ 'cf-script' ];
    }

    protected function _register_controls(){
        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );
        $this->add_group_control(
			\Elementor\Group_Control_Image_Size::get_type(),
			[
				'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
				'exclude' => [ 'custom' ],
				'include' => [],
				'default' => 'large',
			]
		);
        $this->add_control(
			'widget_title',
			[
				'label' => __( 'Title', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Default title', 'plugin-domain' ),
				'placeholder' => __( 'Type your title here', 'plugin-domain' ),
			]
        );
        $this->add_control(
			'description',
			[
				'label' => __( 'Description', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 3,
				'default' => __( 'Default description', 'plugin-domain' ),
				'placeholder' => __( 'Type your description here', 'plugin-domain' ),
			]
		);
        $this->add_control(
			'btn_title',
			[
				'label' => __( 'Button Title', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Learn More', 'plugin-domain' ),
				'placeholder' => __( 'Type your title here', 'plugin-domain' ),
			]
        );
        $this->add_control(
			'link',
			[
				'label' => __( 'Link', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();
    }
    protected function render() {
        $settings = $this->get_settings_for_display();
        $target = $settings['link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
        $link_tag = '<a href="' . $settings['link']['url'] . '"' . $target . $nofollow . '>'. $settings['btn_title'] .'</a>';

        ?>
        <div class="cf_content_box">
            <div class="cf_content_box_image" style="background-image: url(<?php echo Group_Control_Image_Size::get_attachment_image_src( $settings['image']['id'], 'thumbnail', $settings ); ?>);">
                <h2><?php echo $settings['widget_title']; ?></h2>
            </div>
            <div class="content_box_info">
                <?php echo wpautop($settings['description']); ?>
                <?php echo $link_tag; ?>
            </div>
        </div>

        <?php
    }

}
<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class CF_Posts_Grid_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return "cf_posts_grid";
    }
    public function get_title() {
        return "CF Posts Grid";
    }
    
    public function get_icon() {
        return "eicon-gallery-grid";
    }
    public function get_categories() {
        return [ 'general', 'cf-cat' ];
    }
    public function get_post_types() {
        $post_types = cf_get_post_types( [],[ 'elementor_library', 'attachment', 'page' ] );
		return $post_types;
    }
	public function get_style_depends() {
		return [ 'cf-style' ];
	}
	public function get_script_depends() {
		return [ 'cf-script' ];
    }

    protected function _register_controls(){

        $this->start_controls_section(
			'_section_post_tab_query',
			[
				'label' => __( 'Query', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
        
		$this->add_control(
			'post_type',
			[
				'label' => __( 'Source', 'plugin-name' ),
				'type' => Controls_Manager::SELECT,
				'options' => $this->get_post_types(),
				'default' => key( $this->get_post_types() ),
			]
        );
        $this->add_control(
			'item_limit',
			[
				'label' => __( 'Item Limit', 'plugin-name' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 3,
				'dynamic' => [ 'active' => true ],
			]
		);
		$this->add_responsive_control(
            'columns',
            [
                'label' => __( 'Columns', 'plugin-name' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1 => __( '1 Columns', 'plugin-name' ),
                    2 => __( '2 Columns', 'plugin-name' ),
                    3 => __( '3 Columns', 'plugin-name' ),
                    4 => __( '4 Columns', 'plugin-name' ),
                    5 => __( '5 Columns', 'plugin-name' ),
                ],
                'separator' => 'before',
                'desktop_default' => 4,
                'tablet_default' => 3,
                'mobile_default' => 2,
                'prefix_class' => 'single_post_box--col-',
                'selectors' => [
                    '{{WRAPPER}} .single_post_box' => 'width: calc(100% / {{VALUE}});',
                ],
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();
        
        
        
        $this->start_controls_section(
			'_section_grid_settings',
			[
				'label' => __( 'Settings', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'show_excerpt',
			[
				'label' => __( 'Show Excerpt', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'your-plugin' ),
				'label_off' => __( 'Hide', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
			'ex_lenth',
			[
				'label' => __( 'Except Lenth', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20,
				'condition' => [
					'show_excerpt' => 'yes'
				],
			]
		);
		$this->add_control(
			'show_date',
			[
				'label' => __( 'Show Date', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'your-plugin' ),
				'label_off' => __( 'Hide', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'show_readmore',
			[
				'label' => __( 'Show Read more', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'your-plugin' ),
				'label_off' => __( 'Hide', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'readmore_text',
			[
				'label' => __( 'Read More Title', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Read More', 'plugin-domain' ),
				'placeholder' => __( 'Type your title here', 'plugin-domain' ),
				'condition' => [
					'show_readmore' => 'yes'
				],
			]
		);
		$this->end_controls_section();
        
        
        
        $this->start_controls_section(
			'_section_style_common',
			[
				'label' => __( 'Common', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'col_space',
			[
				'label' => __( 'Column Space', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min' => 2,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single_post_box' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'col_bottom_space',
			[
				'label' => __( 'Column Bottom Space', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .single_post_box' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
        
        
        
        $this->start_controls_section(
			'_section_style_title',
			[
				'label' => __( 'Title', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .cf_post_title a' => 'color: {{VALUE}}',
				],
			]
        );
        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .cf_post_title',
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'_section_style_Content',
			[
				'label' => __( 'Content', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'content_color',
			[
				'label' => __( 'Content Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .cf_post_content p' => 'color: {{VALUE}}',
				],
			]
        );
        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .cf_post_content p',
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'_section_style_btn',
			[
				'label' => __( 'Buttom', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'btn_color',
			[
				'label' => __( 'Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .cf_post_btn' => 'color: {{VALUE}}',
				],
				'default'=>'#FFFFFF',
			]
        );
        $this->add_control(
			'btn_bg_color',
			[
				'label' => __( 'Background Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .cf_post_btn' => 'background-color: {{VALUE}}',
				],
				'default'=>'#000000',
			]
        );
        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .cf_post_btn',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .cf_post_btn',
			]
		);
		$this->add_control(
			'btn_brds',
			[
				'label' => __( 'Border Radius', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', ],
				'selectors' => [
					'{{WRAPPER}} .cf_post_btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'_section_style_image',
			[
				'label' => __( 'Image', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'img_space',
			[
				'label' => __( 'Space Bottom', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min' => 2,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cf_post_thumb img' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
			'image_size',
			[
				'label' => __( 'Image Size', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'medium',
				'options' => [
					'thumbnail'  => __( 'Thumbnail', 'plugin-domain' ),
					'medium'  => __( 'Medium', 'plugin-domain' ),
					'medium_large'  => __( 'Medium Large', 'plugin-domain' ),
					'full'  => __( 'Full', 'plugin-domain' ),
					'1536x1536'  => __( '1536x1536', 'plugin-domain' ),
					'2048x2048'  => __( '2048x2048', 'plugin-domain' ),
				],
			]
		);

		$this->add_control(
			'image_brds',
			[
				'label' => __( 'Border Radius', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', ],
				'selectors' => [
					'{{WRAPPER}} .cf_post_thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'_section_style_meta',
			[
				'label' => __( 'Meta', 'plugin-name' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'date_space',
			[
				'label' => __( 'Date Space Bottom', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min' => 2,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cf_post_thumb img' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
			'meta_color',
			[
				'label' => __( 'Date Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .date_time' => 'color: {{VALUE}}',
				],
			]
        );
        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'date_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .date_time',
			]
        );
        $this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		
        $this->add_control(
			'location_color',
			[
				'label' => __( 'Location Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .location' => 'color: {{VALUE}}',
				],
			]
        );
        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'location_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .location',
			]
		);
        $this->end_controls_section();
    }


    
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        if ( !$settings['post_type'] ) {
            return;
        }

        $post_args = [
			'post_status'      => 'publish',
			'post_type'        => $settings['post_type'],
			'posts_per_page'   => $settings['item_limit'],
			'suppress_filters' => false,
		];

        $posts = get_posts( $post_args );
        ?>

        <div class="cf_posts_grid">
            
            <div class="post_grid_wrapper">
				<?php if($posts):
				foreach($posts as $post) : ?>
                    <div class="single_post_box">
                        <h2 class="cf_post_title">
                            <a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>"> <?php echo esc_html( $post->post_title ); ?></a>
                        </h2>
                        <div class="cf_post_thumb">
                            <?php if(has_post_thumbnail($post->ID)) : ?>
                            <a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>">
                                <?php echo get_the_post_thumbnail($post->ID, $settings['image_size'],['class'=> '']); ?>
                            </a>
                            <?php endif; ?>
                        </div>
						
						<?php if($settings['show_excerpt'] == 'yes') : ?>
							<div class="cf_post_content">
								<?php echo wpautop(wp_trim_words(get_the_content(null,false, $post), $settings['ex_lenth'])); ?>
							</div>
						<?php endif; ?>
						<?php if ( $settings['show_date'] == 'yes' ): ?>
							<?php if(get_field( 'event_date', $post->ID ) || get_field('location', $post->ID)) : ?>
							<div class="cf_post_meta">
								<span class="date_time"><?php echo get_field( 'event_date', $post->ID );?></span>
								<span class="location"><?php echo get_field('location', $post->ID); ?></span>
							</div>
							<?php endif; ?>
						<?php endif;?>
						<?php if($settings['show_readmore'] == 'yes') : ?>
							<a class="cf_post_btn" href="<?php echo esc_url(get_the_permalink($post->ID)); ?>"><?php echo $settings['readmore_text']; ?></a>
						<?php endif; ?>
                    </div>
				<?php endforeach;
				else: ?>
				<div class="no_post_found">
					<h2>No posts found</h2>
				</div>
				<?php endif; ?>
                </div>
            </div>
        </div>


        <?php


    }

    protected function _content_template() {}
}